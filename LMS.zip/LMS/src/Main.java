import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class Main {
    private static JFrame frame;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::showHomePage);
    }

    private static void showHomePage() {
        frame = new JFrame("Library Management System");
        frame.setLocation(450,100);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        frame.add(panel);

        JLabel welcomeLabel = new JLabel("Welcome to Library Management System");
        welcomeLabel.setFont(new Font("Elephant", Font.BOLD, 16));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        panel.add(welcomeLabel, gbc);

        JButton showAllBooksButton = new JButton("Show All Books");
        showAllBooksButton.setBackground(Color.BLUE);
        showAllBooksButton.setForeground(Color.WHITE);
        panel.add(showAllBooksButton, gbc);

        JButton insertBookButton = new JButton("Insert Book");
        insertBookButton.setBackground(Color.GREEN);
        insertBookButton.setForeground(Color.WHITE);
        panel.add(insertBookButton, gbc);

        JButton deleteBookButton = new JButton("Delete Book");
        deleteBookButton.setBackground(Color.RED);
        deleteBookButton.setForeground(Color.WHITE);
        panel.add(deleteBookButton, gbc);

        JButton editBookButton = new JButton("Edit Book");
        editBookButton.setBackground(Color.ORANGE);
        editBookButton.setForeground(Color.WHITE);
        panel.add(editBookButton, gbc);

        showAllBooksButton.addActionListener(e -> showAllBooks());
        insertBookButton.addActionListener(e -> showInsertBookDialog());
        deleteBookButton.addActionListener(e -> showDeleteBookDialog());
        editBookButton.addActionListener(e -> showEditBookDialog());

        frame.setSize(400, 500);
        frame.setVisible(true);
    }

    private static void showAllBooks() {

        String url = "jdbc:mysql://localhost:3306/library?useSSL=false";
        String user = "root";
        String dbPassword = "123456789";
        String sql = "SELECT * FROM books";

        try (Connection connection = DriverManager.getConnection(url, user, dbPassword);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            String[] columnNames = {"Title", "Author", "Year", "Genre"};
            DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);

            while (resultSet.next()) {
                String title = resultSet.getString("title");
                String author = resultSet.getString("author");
                int year = resultSet.getInt("year");
                String genre = resultSet.getString("genre");
                tableModel.addRow(new Object[]{title, author, year, genre});
            }

            JTable table = new JTable(tableModel);
            JOptionPane.showMessageDialog(null, new JScrollPane(table), "All Books", JOptionPane.PLAIN_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error executing SQL statement: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void showInsertBookDialog() {
        JTextField titleField = new JTextField(10);
        JTextField authorField = new JTextField(10);
        JTextField yearField = new JTextField(10);
        JTextField genreField = new JTextField(10);

        JPanel panel = new JPanel(new GridLayout(5, 2));
        panel.add(new JLabel("Title:"));
        panel.add(titleField);
        panel.add(new JLabel("Author:"));
        panel.add(authorField);
        panel.add(new JLabel("Year:"));
        panel.add(yearField);
        panel.add(new JLabel("Genre:"));
        panel.add(genreField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Insert Book", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String title = titleField.getText();
            String author = authorField.getText();
            String yearText = yearField.getText();
            String genre = genreField.getText();

            if (title.isEmpty() || author.isEmpty() || yearText.isEmpty() || genre.isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields are required.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                int year = Integer.parseInt(yearText);
                if (insertBook(title, author, year, genre)) {
                    JOptionPane.showMessageDialog(null, "Book record inserted successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "Insertion failed.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Year must be a number.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    private static boolean insertBook(String title, String author, int year, String genre) {
        String url = "jdbc:mysql://localhost:3306/library?useSSL=false";
        String user = "root";
        String dbPassword = "123456789";
        String sql = "INSERT INTO books (title, author, year, genre) VALUES (?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(url, user, dbPassword);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, title);
            preparedStatement.setString(2, author);
            preparedStatement.setInt(3, year);
            preparedStatement.setString(4, genre);
            int rowsInserted = preparedStatement.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error executing SQL statement: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    private static void showDeleteBookDialog() {
        String bookTitle = JOptionPane.showInputDialog(null, "Enter Book Title to Delete:");
        if (bookTitle != null && !bookTitle.trim().isEmpty()) {
            if (deleteBook(bookTitle)) {
                JOptionPane.showMessageDialog(null, "Book record deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(null, "Deletion failed.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please enter a valid title.", "Validation Error", JOptionPane.WARNING_MESSAGE);
        }
    }

    private static boolean deleteBook(String bookTitle) {
        String url = "jdbc:mysql://localhost:3306/library?useSSL=false";
        String user = "root";
        String dbPassword = "123456789";
        String sql = "DELETE FROM books WHERE title = ?";

        try (Connection connection = DriverManager.getConnection(url, user, dbPassword);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, bookTitle);
            int rowsDeleted = preparedStatement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error executing SQL statement: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    private static void showEditBookDialog() {
        String bookTitle = JOptionPane.showInputDialog(null, "Enter Book Title to Edit:");
        if (bookTitle != null && !bookTitle.trim().isEmpty()) {
            editBook(bookTitle);
        } else {
            JOptionPane.showMessageDialog(null, "Please enter a valid title.", "Validation Error", JOptionPane.WARNING_MESSAGE);
        }
    }

    private static void editBook(String bookTitle) {
        JTextField newTitleField = new JTextField(10);
        JTextField newAuthorField = new JTextField(10);
        JTextField newYearField = new JTextField(10);
        JTextField newGenreField = new JTextField(10);

        JPanel panel = new JPanel(new GridLayout(5, 2));
        panel.add(new JLabel("New Title:"));
        panel.add(newTitleField);
        panel.add(new JLabel("New Author:"));
        panel.add(newAuthorField);
        panel.add(new JLabel("New Year:"));
        panel.add(newYearField);
        panel.add(new JLabel("New Genre:"));
        panel.add(newGenreField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Edit Book", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String newTitle = newTitleField.getText();
            String newAuthor = newAuthorField.getText();
            String newYearText = newYearField.getText();
            String newGenre = newGenreField.getText();

            if (newTitle.isEmpty() || newAuthor.isEmpty() || newYearText.isEmpty() || newGenre.isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields are required.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                int newYear = Integer.parseInt(newYearText);
                if (updateBook(bookTitle, newTitle, newAuthor, newYear, newGenre)) {
                    JOptionPane.showMessageDialog(null, "Book record updated successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "Update failed.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Year must be a number.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    private static boolean updateBook(String oldTitle, String newTitle, String newAuthor, int newYear, String newGenre) {
        String url = "jdbc:mysql://localhost:3306/library?useSSL=false";
        String user = "root";
        String dbPassword = "123456789";
        String sql = "UPDATE books SET title = ?, author = ?, year = ?, genre = ? WHERE title = ?";

        try (Connection connection = DriverManager.getConnection(url, user, dbPassword);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, newTitle);
            preparedStatement.setString(2, newAuthor);
            preparedStatement.setInt(3, newYear);
            preparedStatement.setString(4, newGenre);
            preparedStatement.setString(5, oldTitle);
            int rowsUpdated = preparedStatement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error executing SQL statement: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}
